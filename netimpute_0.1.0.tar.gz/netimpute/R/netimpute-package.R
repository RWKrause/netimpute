#' netimpute: Joint Multiple Imputation of Network Ties and Node Attributes
#'
#' netimpute imputes missing nodal attributes and missing network ties
#' together, in a single chained-equations loop. Attributes are imputed from
#' node-level network measures (\code{\link{net_measures}}) and the other
#' attributes; ties are imputed from dyad-level predictors built from the
#' attributes and the other networks (\code{\link{dyad_regression}}). Both
#' predictor sets are rebuilt at every visit, so each data type informs the
#' other as the chain progresses.
#'
#' The main entry point is \code{\link{netmice}}; use
#' \code{\link{complete_netmice}} to extract a completed data set and
#' \code{\link{plot.netmids}} for convergence diagnostics. Supporting
#' functions are \code{\link{net_measures}} (with the
#' \code{\link{net_measures_core}} / \code{\link{net_measures_full}}
#' wrappers), \code{\link{net_predictors}}, \code{\link{dyad_regression}},
#' \code{\link{netquickpred}}, and \code{\link{net_diagnostics}}.
#'
#' @keywords internal
"_PACKAGE"
